package Test;


import MyMain.Main;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class MyTest {

    @Test
    public void testConcatenate() {
        Main myClass = new Main(9.4324,15.675,6.189,6.3438);

        try{
            boolean checkInRange = false;
            boolean original = true;
            double randomNumber = myClass.createRandom(9.4324,15.675);
            if (randomNumber >= -31.5963 && randomNumber<= 56.4574){
                checkInRange = true;
            }
            assertEquals(original, checkInRange);

        } catch (NullPointerException e){
            System.out.println("\nPlease enter valid input\n");
        }
    }

    @Before
    public void beforeTest() {
        System.out.println("MyTestClass:Inside @Before");
    }

    @After
    public void afterTest() {
        System.out.println("MyTestClass:Inside @After");
    }






}
