package MyMain;

import java.util.Arrays;

public class Main {

    double [] portfolioValueAgg;
    double [] portfolioValueCons;
    private double aggReturn;
    private double aggRisk;
    private double consReturn;
    private double consRisk;

    public Main(double aggReturn,double aggRisk, double consReturn,double consRisk) {
        // TODO Auto-generated constructor stub

        this.aggReturn = aggReturn;
        this.aggRisk = aggRisk;
        this.consReturn = consReturn;
        this.consRisk = consRisk;

        portfolioValueAgg = new double[10000];
        portfolioValueCons = new double[10000];
    }

    public double  createRandom(double portfolioReturn,double portfolioRisk)
    {
        double low = portfolioReturn - (3*portfolioRisk);
        double range = 6 * portfolioRisk;
        return randomHelper(low, range);
    }

    public double randomHelper(double low,double range)
    {
        double result = 0;
        result = low + (Math.random()*range);
        return result;
    }


    public double[] portfolioSimulator(int simulationCount,double portfolioRisk,double portfolioReturn)
    {
        double[] portfolioValue = new double[simulationCount];
        for(int i = 0;i<simulationCount;i++)
        {
            double myValue = 100000;
            for(int j = 0;j<20;j++)
            {
                double myReturn = createRandom(portfolioReturn, portfolioRisk);
                //System.out.println("Return Random  " + String.valueOf(myReturn));
                double inflationValue = (3.5/100) * myValue;
                //System.out.println("Inflation " +String.valueOf(j) +" " + String.valueOf(inflationValue));
                double returnValue = (myReturn/100) * myValue;
                //System.out.println("ReturnValue " +String.valueOf(j) +" " + String.valueOf(returnValue));
                myValue = inflationValue+returnValue+myValue;
                //System.out.println("End of Year " +String.valueOf(j) +" " + String.valueOf(myValue));
            }
            //System.out.println("\n\n");
            portfolioValue[i] = myValue;
        }
        sortingArray(portfolioValue);
        return portfolioValue;
    }

    public void sortingArray(double [] toBeSortedArray)
    {
        Arrays.sort(toBeSortedArray);
    }

    public void run()
    {

		//Simulating for Aggressive
		portfolioValueAgg = portfolioSimulator(10000,aggRisk,aggReturn);
		portfolioValueCons = portfolioSimulator(10000, consRisk, consReturn);
		System.out.println("Aggressive");
		System.out.println(portfolioValueAgg[8999]);
		System.out.println(portfolioValueAgg[9000]);
		System.out.println(portfolioValueAgg[999]);
		System.out.println(portfolioValueAgg[1000]);
		System.out.println("Median " + String.valueOf((portfolioValueAgg[4999]+portfolioValueAgg[5000])/2));
		//System.out.println(Arrays.toString(portfolioValueAgg));
		System.out.println("Very Conservative");
		System.out.println(portfolioValueCons[8999]);
		System.out.println(portfolioValueCons[999]);
		System.out.println("Median " + String.valueOf((portfolioValueCons[4999]+portfolioValueCons[5000])/2));

    }
    public static void main(String[] args)
    {
        new Main(9.4324,15.675,6.189,6.3438).run();
    }
}